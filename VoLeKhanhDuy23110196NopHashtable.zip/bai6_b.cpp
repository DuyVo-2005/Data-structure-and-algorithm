﻿// bai6_b.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<string>
#include<string.h>
using namespace std;
//Định nghĩa bảng băm
#define MAX 15
#define FALSE 0
#define TRUE 1
#define NullKey -99999999
#define NullIndex -1
typedef struct tagNode
{
	string key;//khoa cua nut tren bang bam
	int nextIndex;//con tro chi nut ke tiep khi co xung dot
} Node;
Node* hashtable[MAX];//Khai bao bang bam
void InitHashtable(Node* hashtable[MAX]) {
	for (int b = 0; b < MAX; b++) 
		hashtable[b] = nullptr;
}
int HashFunction(string x)
{
	return ((int(x[0]) + int(x[1])) / 2 )% 11;
}
Node* CreateNode(string x) {
	Node* p = new Node;
	if (p == NULL)	exit(1);
	p->key = x;
	p->nextIndex= NullIndex;
	return p;
}
void AddItem(string x) {
	int b = HashFunction(x);
	Node* p = CreateNode(x);
	if (hashtable[b] == nullptr) {//khong dung do
		hashtable[b] = p;
	}
	else
	{//co dung do
		//tim vi tri thich hop de chen
		int pos;
		for (pos = MAX - 1; pos >= 0; pos--) {
			if (hashtable[pos] == nullptr) {
				hashtable[pos] = p;
				break;
			}
		}
		if (pos < 0) {
			cout << "\nKhong chen duoc do bang bam day!";
			exit(1);
		}

		// cap nhat p->Next nut truoc nut vua chen la nut vua chen
		while (hashtable[b]->nextIndex != NullIndex) {
			b = hashtable[b]->nextIndex;
		}
		hashtable[b]->nextIndex = pos;
	}
}
void Traverse(Node* hashtable[MAX]) {
	for (int b = 0; b < MAX; b++)
		if(hashtable[b] != nullptr)
			cout << "\nBucket " << b << ": key " << hashtable[b]->key << " | next index " << hashtable[b]->nextIndex;
		else
		{
			cout << "\nBucket " << b << ": key NullKey  | next index " << -1;
		}
}
int main()
{
	cout << "\nChen ab";
	InitHashtable(hashtable);
	AddItem("ab");
	Traverse(hashtable);
	cout << "\n\nChen AC";
	AddItem("AC");
	Traverse(hashtable);
	cout << "\n\nChen de";
	AddItem("de");
	Traverse(hashtable);
	cout << "\n\nChen Fg";
	AddItem("Fg");
	Traverse(hashtable);
	cout << "\n\nChen DH";
	AddItem("DH");
	Traverse(hashtable);
	cout << "\n\nChen LM";
	AddItem("LM");
	Traverse(hashtable);
	cout << "\n\nChen KF";
	AddItem("KF");
	Traverse(hashtable);
	cout << "\n\nChen cA";
	AddItem("cA");
	Traverse(hashtable);
	cout << "\n\nChen gH";
	AddItem("gH");
	Traverse(hashtable);
	cout << "\n\nChen iX";
	AddItem("iX");
	Traverse(hashtable);
	cout << "\n\nChen xK";
	AddItem("xK");
	Traverse(hashtable);
	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
