#include<iostream>
#include<string>
#include<string.h>
using namespace std;
#define MAX 15
#define NONE "NONE"
string hashtable[MAX];
void FillHashtable(string hashtable[], string x) {
	for (int i = 0; i < MAX; i++)	hashtable[i] = x;
}
int HashFunction(string x)
{
	return (int(x[0]) + int(x[1])) / 2 % 11;
}
bool IsFullHashtable(string hashtable[MAX]) {
	for (int i = 0; i < MAX; i++)
		if (hashtable[i] == NONE)	return false;
	return true;
}
void AddItem(string x) {
	if (IsFullHashtable(hashtable))	cout << "\nBang bam day! Khong them phan tu duoc!";
	else {
		int b = HashFunction(x);
		if (hashtable[b] == NONE)	hashtable[b] = x;
		else {
			for (int i = 1; i < MAX; i++)
				if (hashtable[b + i] == NONE) {
					hashtable[b + i] = x;
					break;
				}
		}
	}
}
void RemoveItem(string hashtable[MAX], string x) {
	int b = HashFunction(x);
	if (hashtable[b] == x) {
		hashtable[b] = NONE;
		return;
	}
	else {
		for (int i = 1; i < MAX; i++)
			if (hashtable[b + i] == x) {
				hashtable[b + i] = NONE;
				return;
			}
	}
	cout << "\nKhong tim thay phan tu can xoa!";
}
int SearchItem(string hashtable[MAX], string x) {
	//tra ve vi tri luu tru khoa x
	int b = HashFunction(x);
	if (hashtable[b] == x)	return b;
	else {
		for (int i = 1; i < MAX; i++) {
			if (hashtable[b + i] == x)	return b + i;
		}
	}
	return -1;
}
void Traverse(string hashtable[]) {
	cout << "\n";
	for (int i = 0; i < MAX; i++)
		if (hashtable[i] != NONE)	cout << "\n" << i << "\t" << hashtable[i];
		else	cout << "\n" << i << "\t" << "NONE";
}
int main() {
	FillHashtable(hashtable, NONE);
	cout << "\nChen ab";
	AddItem("ab");
	Traverse(hashtable);
	cout << "\n\nChen AC";
	AddItem("AC");
	Traverse(hashtable);
	cout << "\n\nChen de";
	AddItem("de");
	Traverse(hashtable);
	cout << "\n\nChen Fg";
	AddItem("Fg");
	Traverse(hashtable);
	cout << "\n\nChen DH";
	AddItem("DH");
	Traverse(hashtable);
	cout << "\n\nChen LM";
	AddItem("LM");
	Traverse(hashtable);
	cout << "\n\nChen KF";
	AddItem("KF");
	Traverse(hashtable);
	cout << "\n\nChen cA";
	AddItem("cA");
	Traverse(hashtable);
	cout << "\n\nChen gH";
	AddItem("gH");
	Traverse(hashtable);
	cout << "\n\nChen iX";
	AddItem("iX");
	Traverse(hashtable);
	cout << "\n\nChen xK";
	AddItem("xK");
	Traverse(hashtable);
	return 0;
}





