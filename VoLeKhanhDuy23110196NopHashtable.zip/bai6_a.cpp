﻿// bai5_1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
//Định nghĩa bảng băm
#define MAX 15
#define FALSE 0
#define TRUE 1
#define NONE "NONE"
typedef struct tagNode
{
	string key;
	tagNode* pNext;
} Node;
typedef struct
{
	Node* pHead;
	Node* pTail;
}LINKEDLIST;
LINKEDLIST hashtable[MAX];
Node* CreateNode(string x) {
	Node* p = new Node;
	if (p == NULL)   return NULL;
	p->key = x;
	p->pNext = NULL;
	return p;
}
void InitList(LINKEDLIST& l) {
	l.pHead = l.pTail = NULL;
}
void InitHashtable(LINKEDLIST hashtable[]) {
	for (int b = 0; b < MAX; b++)	InitList(hashtable[b]);
}
bool IsEmptyList(LINKEDLIST l) {
	return l.pHead == NULL;
}
void AddFirst(LINKEDLIST& l, string x) {
	Node* p = CreateNode(x);
	if (IsEmptyList(l))  l.pHead = l.pTail = p;
	else {
		p->pNext = l.pHead;
		l.pHead = p;
	}
}
void AddLast(LINKEDLIST& l, string x) {
	Node* p = CreateNode(x);
	if (IsEmptyList(l))  l.pHead = l.pTail = p;
	else {
		l.pTail->pNext = p;
		l.pTail = p;
	}
}
void AddAfter(LINKEDLIST& l, Node* p, string x) {
	//them node moi sau node p
	Node* q = CreateNode(x);
	if (p == NULL || q == NULL)  cout << "\nKhong them node moi duoc!";
	else {
		q->pNext = p->pNext;//luu dia chi phia sau q truoc
		p->pNext = q;
		if (p == l.pTail)    l.pTail = q;
	}
}
void RemoveFirst(LINKEDLIST& l) {
	if (IsEmptyList(l))  cout << "\nKhong xoa duoc do list rong!";
	else if (l.pHead == l.pTail) {
		//1 phan tu
		delete l.pHead;
		l.pHead = l.pTail = NULL;
	}
	else {
		Node* p = l.pHead;
		l.pHead = l.pHead->pNext;
		delete p;
	}
}
void RemoveLast(LINKEDLIST& l) {
	if (IsEmptyList(l)) cout << "\nKhong xoa duoc do list rong!";
	else if (l.pHead == l.pTail) {//1 phan tu
		delete l.pHead;
		l.pHead = l.pTail = NULL;
	}
	else {
		//nhieu hon 1 phan tu
		Node* p = l.pHead;// p la nut truoc l.tail
		while (p->pNext != l.pTail) {
			p = p->pNext;
		}
		delete l.pTail;
		l.pTail = p;
		l.pTail->pNext = NULL;
	}
}
int HashFunction(string x);
void PushElementToTheBeginningOfHashTable(int b, string x)
{
	Node* p = new Node;
	p->key = x;
	p->pNext = hashtable[b].pHead;
	hashtable[b].pHead = p;
}
void Place(int b, string k)
{
	Node* p, * q;
	q = NULL;
	for (p = hashtable[b].pHead; p != NULL && k > p->key; p = p->pNext)
		q = p;
	if (q == NULL)
		PushElementToTheBeginningOfHashTable(b, k);
	else
		AddAfter(hashtable[b], q, k);
}
int HashFunction(string x){
	return (int(x[0]) + int(x[1])) / 2 % 11;
}
void AddItem(string x) {
	int b = HashFunction(x);
	Place(b, x); //chen x vao danh sach lien ket
}
void FreeNode(Node* p) {
	delete p;
}
bool IsEmptyBucket(int b) {
	return hashtable[b].pHead == NULL;
}
string PopThebeginningOfBucket(int b)
{
	Node* p;
	string k;
	if (IsEmptyBucket(b)) {
		cout << "Bucket dang rong, khong xoa duoc!";
		return NONE;
	}
	p = hashtable[b].pHead; k = p->key;
	hashtable[b].pHead = p->pNext; FreeNode(p);
	return k;
}
string RemoveAfter(Node* p) {
	Node* q;//nut can xoa la q
	string k;
	if (p == NULL || p->pNext == NULL) {
		cout << "\nKhong xoa node duoc!";
		return FALSE;
	}
	q = p->pNext;
	k = q->key;
	p->pNext = q->pNext;
	FreeNode(q);
	return k;
}
void RemoveItem(LINKEDLIST hashtable[MAX], string x) {
	Node* p, * q = NULL;
	int b = HashFunction(x);
	p = hashtable[b].pHead;
	while (p != NULL && p->key != x) {
		q = p;
		p = p->pNext;
	}
	if (p == NULL)	cout << "\nKhong co node co khoa can xoa!";
	else if (p == hashtable[b].pHead)	PopThebeginningOfBucket(b);
	else	RemoveAfter(q);
}
int SearchNode(LINKEDLIST l, string x) {
	for (Node* p = l.pHead; p != NULL; p = p->pNext)
		if (p->key == x) return HashFunction(x);//tim thay tai vi tri HashFunction(x)
	return -1;//khong tim thay
}
int SearchItem(LINKEDLIST hashtable[MAX], string x)
{
	int index = HashFunction(x);
	return SearchNode(hashtable[index], x);
	//tim thay -> return vi tri, khong tim thay -> return -1
}
void TraverseBucket(int b) {
	Node* p = hashtable[b].pHead;
	while (p != NULL) {
		cout << p->key << " ";
		p = p->pNext;
	}
}
void Traverse(LINKEDLIST hashtable[]) {
	for (int b = 0; b < MAX; b++) {
		cout << "\nBucket thu " << b << ": ";
		TraverseBucket(b);
	}
}
int main()
{
	InitHashtable(hashtable);
	cout << "\nChen ab";
	AddItem("ab");
	Traverse(hashtable);
	cout << "\n\nChen AC";
	AddItem("AC");
	Traverse(hashtable);
	cout << "\n\nChen de";
	AddItem("de");
	Traverse(hashtable);
	cout << "\n\nChen Fg";
	AddItem("Fg");
	Traverse(hashtable);
	cout << "\n\nChen DH";
	AddItem("DH");
	Traverse(hashtable);
	cout << "\n\nChen LM";
	AddItem("LM");
	Traverse(hashtable);
	cout << "\n\nChen KF";
	AddItem("KF");
	Traverse(hashtable);
	cout << "\n\nChen cA";
	AddItem("cA");
	Traverse(hashtable);
	cout << "\n\nChen gH";
	AddItem("gH");
	Traverse(hashtable);
	cout << "\n\nChen iX";
	AddItem("iX");
	Traverse(hashtable);
	cout << "\n\nChen xK";
	AddItem("xK");
	Traverse(hashtable);
	return 0;
}
