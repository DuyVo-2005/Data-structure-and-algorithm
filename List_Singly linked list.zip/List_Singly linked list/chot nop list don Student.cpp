// chot nop list don Student.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
#include<string>
#include<fstream>
struct STUDENT {
	string id;
	string name;
	float gpa;
};
#define elementType STUDENT
struct NODE {
	elementType info;
	struct NODE* next;
};
struct LIST {
	NODE* head;
	NODE* tail;
};
ifstream infile;
ofstream outfile;
int n;// so luong phan tu list
void initList(LIST& l);
NODE* createNode(elementType x);
int isEmptyList(LIST l);
void addFirst(LIST& l, elementType x);
void addLast(LIST& l, elementType x);
void removeFirst(LIST& l);
void removeLast(LIST& l);
elementType searchNode(LIST l, NODE* x);
void printElement(STUDENT x);
void printList(LIST l);
void addLast(LIST& l, NODE* p);
void QuickSort(LIST& l);
void decreasingQuickSort(LIST& l);
void doSort(LIST& l);
void enterList(LIST &l);
void enterElement(STUDENT& x);
bool isSmaller(float a, float b);
void insertElementNotChangeOrder(LIST& l, NODE *p);
bool isGreaterOrEqual(float a, float b);
LIST takeElementsIsMoreOrEqualX(LIST l, float x, bool& flag);
void removeElementsIsMoreOrEqualX(LIST& l, float x);
void findKStudentHaveTheMostGPA(LIST &l, int k);
int main()
{
	infile.open("C:\\Users\\HP\\OneDrive\\Documents\\V� L� KH�NH DUY\\dsa\\input dslk don sv.txt");
	outfile.open("C:\\Users\\HP\\OneDrive\\Documents\\V� L� KH�NH DUY\\dsa\\output dslk don sv.txt");
	LIST l;
	initList(l);
	outfile << "\nDanh sach sau khi doc file: " << "\n";
	enterList(l);
	printList(l);
	outfile << "\n---------------\n";
		
	STUDENT a;
	enterElement(a);
	outfile << "Sinh vien moi can chen: \n";
	printElement(a);
	outfile << "\nDanh sach sau khi chen sinh vien moi khong lam doi thu tu: \n";
	NODE* p = createNode(a);
	insertElementNotChangeOrder(l,p);
	printList(l);
	outfile << "\n---------------\n";

	float tmp;
	infile >> tmp;
	bool flag = false;// gia su khong co hoc sinh nao co gpa lon hon hoac bang x
	LIST l2;
	initList(l2);
	l2=takeElementsIsMoreOrEqualX(l, tmp, flag);
	if (flag == true) {
		outfile << "Danh sach lay ra cac sinh vien co diem trung binh lon hon hoac bang " << tmp << ": ";
		printList(l2);
	}
	else
		outfile << "\nKhong khong co hoc sinh nao co gpa lon hon hoac bang x!";
	outfile << "\n---------------\n";

	float tmp2;
	infile >> tmp2;
	removeElementsIsMoreOrEqualX(l,tmp2);
	outfile << "\nDanh sach sau khi xoa cac sinh vien co diem trung binh lon hon hoac bang " << tmp2 << ": \n";
	printList(l);
	outfile << "\n---------------\n";

	int k;
	infile >> k;
	outfile << "\n" << k << " sinh vien co diem trung binh cao nhat: ";
	findKStudentHaveTheMostGPA(l, k);
	infile.close();
	outfile.close();
	return 0;
}
void initList(LIST& l) {
	l.head = l.tail = NULL;
}
NODE* createNode(elementType x) {
	NODE* p;
	p = new NODE;
	if (p == NULL) {
		outfile << "\nBo nho day! Khong tao node duoc!";
		exit(1);
	}
	p->info = x;
	p->next = NULL;
	return p;
}
int isEmptyList(LIST l) {
	if (l.head == NULL)	return 1;
	return 0;
	//1 dung, 0 sai
}
void addFirst(LIST& l, elementType x) {
	NODE* p = createNode(x);
	if (isEmptyList(l))
	{
		l.head = p;
		l.tail = p;
	}
	else {
		p->next = l.head;
		l.head = p;
	}
}
void addLast(LIST& l, elementType x) {
	NODE* p = createNode(x);
	if (isEmptyList(l))
		l.head = l.tail = p;
	else {
		l.tail->next = p;
		l.tail = p;
	}
}
void removeFirst(LIST& l) {
	if (isEmptyList(l))
		outfile << "Khong huy duoc do danh sach rong! ";
	else {
		if (l.head == l.tail)
			l.head = l.tail = NULL;
		else {
			NODE* p = l.head;
			l.head = l.head->next;
			delete p;
		}
	}
}
void removeLast(LIST& l) {
	if (isEmptyList(l)) {
		outfile << "\nList rong! Khong huy duoc!";
		exit(1);
	}
	else {
		if (l.head == l.tail)//1 phan tu
		{
			l.head = NULL;
			l.tail = NULL;
		}
		else {
			//nhieu hon 1 phan tu
			NODE* p = l.head;// p la nut truoc l.tail
			while (p->next != l.tail) {
				p = p->next;
			}
			delete l.tail;
			l.tail = p;
			l.tail->next = NULL;
		}
	}
}
elementType searchNode(LIST l, NODE* x) {
	if (x == NULL)
		exit(1);
	else {
		NODE* p = l.head;
		while (p != x) {
			p = p->next;
		}
		if (p != NULL)
			return p->info;
	}
}
void printList(LIST l) {
	for (NODE* p = l.head; p != NULL; p = p->next)
		printElement(p->info);
}
void printElement(STUDENT x) {
	outfile <<"\n"<< x.id << "\n" << x.name << "\n" << x.gpa;
}
void addLast(LIST& l, NODE* p) {
	if (isEmptyList(l))
		l.head = l.tail = p;
	else {
		l.tail->next = p;
		l.tail = p;
	}
}
void QuickSort(LIST& l) {// sort gpa
	if (l.head == l.tail) return;// da co thu tu (0-1 node)
	NODE* p, * x;//x luu gia tri key
	LIST l1, l2;
	initList(l1);
	initList(l2);
	x = l.head;
	for (p = l.head->next; p != NULL;) {
		NODE* q = p;
		p = p->next;
		q->next = NULL;//co lap node dang xet
		if ((q->info.gpa) <= (x->info.gpa))
			addLast(l1, q);
		else
			addLast(l2, q);
	}
	QuickSort(l1);
	QuickSort(l2);
	//noi list1 + x +list2 = list
	if (l1.head != NULL) {
		l.head = l1.head;
		l1.tail->next = x;
	}
	else
		l.head = x;
	x->next = l2.head;//
	if (l2.head != NULL) {
		l.tail = l2.tail;
	}
	else
		l.tail = x;
}
void decreasingQuickSort(LIST& l) {// sort gpa
	if (l.head == l.tail) return;// da co thu tu (0-1 node)
	NODE* p, * x;//x luu gia tri key
	LIST l1, l2;
	initList(l1);
	initList(l2);
	x = l.head;
	for (p = l.head->next; p != NULL;) {
		NODE* q = p;
		p = p->next;
		q->next = NULL;//co lap node dang xet
		if (isGreaterOrEqual(q->info.gpa,x->info.gpa))
			addLast(l1, q);
		else
			addLast(l2, q);
	}
	decreasingQuickSort(l1);//
	decreasingQuickSort(l2);//
	//noi list1 + x +list2 = list
	if (l1.head != NULL) {
		l.head = l1.head;
		l1.tail->next = x;
	}
	else
		l.head = x;
	x->next = l2.head;//
	if (l2.head != NULL) {
		l.tail = l2.tail;
	}
	else
		l.tail = x;
}
void doSort(LIST& l) {
	QuickSort(l);
}
void enterList(LIST& l) {
	infile >> n;
	STUDENT tmp;
	for (int i = 0; i < n; i++) {
		enterElement(tmp);
		addLast(l,createNode(tmp));
	}
}
void enterElement(STUDENT& x) {
	infile.ignore();
	getline(infile, x.id);
	getline(infile, x.name);
	infile >> x.gpa;
}
bool isSmaller(int a, int b) {
	if (a < b)
		return true;
	return false;
}
bool isSmaller(STUDENT a, STUDENT b) {
	if (a.gpa < b.gpa)
		return true;
	return false;
}
void insertElementNotChangeOrder(LIST& l,NODE *x) {
	QuickSort(l);
	NODE* p = l.head, *q=NULL;//q la nut truoc p
	while (p != NULL && isSmaller(p->info, x->info)) {
		q = p;
		p = p->next;
	}
	if (q != NULL) {
		x->next = p;
		q->next = x;
	}
}//
bool isGreaterOrEqual(float a, float b) {
	if (a >= b)
		return true;
	return false;
}
LIST takeElementsIsMoreOrEqualX(LIST l, float x, bool &flag) {
	LIST res;
	initList(res);
	NODE* p = l.head;
	for (; p != NULL; p = p->next) {
		if (isGreaterOrEqual(p->info.gpa, x)) {
			addLast(res, createNode(p->info));
			flag = true;// list moi co phan tu
		}
	}
	return res;
}
void removeElementsIsMoreOrEqualX(LIST& l, float x) {
	//duyet tung phan tu tu dau mang
	while (l.head != NULL && (isGreaterOrEqual(l.head->info.gpa, x)) ){
		NODE* tmp = l.head;
		l.head = l.head->next;
		delete tmp;
	}
	//van con phan tu
	NODE* p = l.head;
	while (p != NULL && p->next != NULL) {
		NODE* q = p->next;//q la nut sau p, q la nut can xoa
		if (isGreaterOrEqual(q->info.gpa,x)) {
			p->next = q->next;
			if (q == l.tail)
				l.tail = p;
			delete q;
		}
		else {
			p = p->next;
		}
	}
}
void findKStudentHaveTheMostGPA(LIST &l, int k) {
	decreasingQuickSort(l);
	NODE* p = l.head;
		while ((k>0)&&(p!=NULL)){
			printElement(p->info);
			p = p->next;
			k--;
		}
}