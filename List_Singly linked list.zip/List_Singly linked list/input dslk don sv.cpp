// nhap lieu.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<fstream>
using namespace std;
#include<string>
struct STUDENT {
    string id;
    string name;
    float gpa;
};
int main()
{
    ofstream outfile;
    outfile.open("C:\\Users\\HP\\OneDrive\\Documents\\V� L� KH�NH DUY\\dsa\\input dslk don sv.txt");
    STUDENT a;
    int n;
    cin >> n;
    outfile << n;
    for (int i = 0; i < n; i++) {
        cin.ignore();
        getline(cin, a.id);
        getline(cin, a.name);
        cin >> a.gpa;
        outfile <<"\n" << a.id << "\n"<<a.name << "\n" << a.gpa;
    }
    STUDENT b;
    cin.ignore();
    getline(cin, b.id);
    getline(cin, b.name);
    cin >> b.gpa;
    outfile << "\n" << b.id << "\n" << b.name << "\n" << b.gpa;
    float tmpGPA, tmpGPA2;
    cin >> tmpGPA >> tmpGPA2;
    outfile << "\n" << tmpGPA<<"\n"<<tmpGPA2;
    int k;
    cin >> k;
    outfile << "\n" << k;
    outfile.close();
    return 0;
}
/*5
23
Khanh Duy
9.6
25
Van A
8.9
27
Thi C
9.1
11
Van E
9.0
18
Thanh H
8.5
16
Van K
9.2
9.0
9.0
2
*/
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file

