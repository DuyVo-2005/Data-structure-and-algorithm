// nop list don.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<fstream>
#define ElementType int
using namespace std;
struct NODE
{
	ElementType info;
	NODE* pNext;
};
struct LIST
{
	NODE* pHead;
	NODE* pTail;
};

ifstream infile;
ofstream outfile;

void initList(LIST& l);
bool isEmptyList(LIST l);
NODE* createNode(ElementType x);
void addFirst(LIST& l, ElementType x);
void addLast(LIST& l, ElementType x);
void removeFirst(LIST& l);
void removeLast(LIST& l);
ElementType searchNode(LIST l, NODE* x);
void printElement(int a);
void printList(LIST l);
void addLast(LIST& l, NODE* p);
void QuickSort(LIST& l);
void doSort(LIST& l);
LIST takeElementsIsMoreOrEqualX(LIST l, ElementType x);
void removeElementsIsMoreOrEqualX(LIST& l, ElementType x);
void decresingQuickSort(LIST& l);
LIST takeElementIsBiggest(LIST &l);
int countNegativeElements(LIST l);
ElementType maxNegativeValue(LIST l);
ElementType minPositiveValue(LIST l);
int countValueX(LIST l, ElementType x);
void enterElement(int& x);
void enterList(LIST& l);

int main()
{
	infile.open("C:\\Users\\HP\\OneDrive\\Documents\\V� L� KH�NH DUY\\dsa\\input dslk don so nguyen.txt");
	outfile.open("C:\\Users\\HP\\OneDrive\\Documents\\V� L� KH�NH DUY\\dsa\\output dslk don vong so nguyen.txt");
	LIST l;
	initList(l);
	enterList(l);
	outfile << "Danh sach sau khi doc file: \n";
	printList(l);
	outfile << "\n---------------\n";
	outfile << "Danh sach lay ra phan tu >= 5: ";
	LIST l2 = takeElementsIsMoreOrEqualX(l, 5);
	outfile << "\n";
	printList(l2);
	outfile << "\n---------------\n";

	outfile << "Danh sach sau khi xoa phan tu >= 5: \n";
	removeElementsIsMoreOrEqualX(l, 5);
	printList(l);
	outfile << "\n---------------\n";

	LIST l3 = takeElementIsBiggest(l);
	outfile << "Danh sach lay ra cac phan tu lon nhat \n";
	printList(l3);
	outfile << "\n---------------\n";

	outfile << "So luong cac phan tu am: " << countNegativeElements(l);
	outfile << "\n---------------\n";

	int res = maxNegativeValue(l);
	if (res == 0)
		outfile << "\nKhong co so am lon nhat mang!";
	else
		outfile << "\nSo am lon  nhat mang: " << res;
	outfile << "\n---------------\n";

	int res2 = minPositiveValue(l);
	if (res2 != -1)
		outfile << "\nGia tri duong nho nhat mang: " << res2;
	else
		outfile << "\nKhong co gia tri duong nho nhat mang!";
	outfile << "\n---------------\n";

	int tmp3 = 1;
	int res3 = countValueX(l, tmp3);
	if (res3 != 0)
		outfile << "\nSo phan tu co gia  tri bang " << tmp3 << ": " << res3;
	else
		outfile << "\nKhong co gia tri nao bang " << tmp3;
	infile.close();
	outfile.close();
	return 0;
}
void addFirst(LIST& l, ElementType x) {
	NODE* p = createNode(x);
	if (isEmptyList(l)) {
		l.pHead = p;
		l.pTail = p;
	}
	else {
		p->pNext = l.pHead;
		l.pHead = p;
	}
	l.pTail->pNext = l.pHead;
}
void addLast(LIST& l, ElementType x) {
	if (isEmptyList(l))
		addFirst(l, x);//cap nhat tail next roi
	else {
		NODE* p = createNode(x);
		l.pTail->pNext = p;
		l.pTail = p;
		l.pTail->pNext = l.pHead;//
	}
}
NODE* createNode(ElementType x) {
	NODE* p = new NODE;
	if (p == NULL) {
		cout << "Khong du bo nho! Khong tao nut moi duoc!";
		return NULL;
	}
	p->info = x;
	p->pNext = NULL;
	return p;
}
void initList(LIST& l) {
	l.pHead = NULL;
	l.pTail = NULL;
}
bool isEmptyList(LIST l) {
	if (l.pHead == NULL)   return true;
	return false;
}
void removeFirst(LIST& l) {
	if (isEmptyList(l))
		outfile << "Khong huy duoc do danh sach rong! ";
	else {
		if (l.pHead == l.pTail)
			l.pHead = l.pTail = NULL;
		else {
			NODE* p = l.pHead;
			l.pHead = l.pHead->pNext;
			delete p;
			l.pTail->pNext = l.pHead;
		}
	}
}
void removeLast(LIST& l) {
	if (isEmptyList(l)) {
		outfile << "\nList rong! Khong huy duoc!";
		exit(1);
	}
	else {
		if (l.pHead == l.pTail)//1 phan tu
		{
			l.pHead = NULL;
			l.pTail = NULL;
		}
		else {
			//nhieu hon 1 phan tu
			NODE* p = l.pHead;// p la nut truoc l.pTail
			while (p->pNext != l.pTail) {
				p = p->pNext;
			}
			delete l.pTail;
			l.pTail = p;
			l.pTail->pNext = l.pHead;
		}
	}
}
ElementType searchNode(LIST l, NODE* x) {
	if (x == NULL)
		exit(1);
	else {
		NODE* p = l.pHead;
		if (p != x) {
			p = p->pNext;
			while (p != x && p != l.pHead) {
				p = p->pNext;
			}
			if (p == x)
				return p->info;
			else
				exit(1);//khong co
		}
		else
			return p->info;
	}
}
void printList(LIST l) {
	NODE* p = l.pHead;
	printElement(p->info);
	outfile << "\n";
	p = p->pNext;
	for (; p != l.pHead; p = p->pNext) {
		printElement(p->info);
		outfile << "\n";
	}
	outfile << "\n";
}
void printElement(int a) {
	outfile << a;
}
void addLast(LIST& l, NODE* p) {
	if (isEmptyList(l))
		l.pHead = l.pTail = p;
	else {
		l.pTail->pNext = p;
		l.pTail = p;
	}
	l.pTail->pNext = l.pHead;
}
void QuickSort(LIST& l) {
	if (l.pHead == NULL) return;// da co thu tu (0-1 node) ko phai l.pHead=l.pTail
	NODE* p, * x;//x luu gia tri key
	LIST l1, l2;
	initList(l1);
	initList(l2);
	x = l.pHead;
	for (p = l.pHead->pNext; p!=l.pHead ;) {
		NODE* q = p;
		p = p->pNext;
		q->pNext = NULL;//co lap node dang xet
		if (q->info <= x->info)
			addLast(l1, q);
		else
			addLast(l2, q);
	}
	QuickSort(l1);
	QuickSort(l2);
	//noi list1 + x +list2 = list
	if (l1.pHead != NULL) {
		l.pHead = l1.pHead;
		l1.pTail->pNext = x;
	}
	else
		l.pHead = x;
	x->pNext = l2.pHead;//
	if (l2.pHead != NULL) {
		l.pTail = l2.pTail;
	}
	else
		l.pTail = x;
	l.pTail->pNext = l.pHead;
}
void doSort(LIST& l) {
	QuickSort(l);
}
LIST takeElementsIsMoreOrEqualX(LIST l, ElementType x) {
	LIST res;
	initList(res);
	NODE* p = l.pHead;
	if (p->info >= x) {
		addLast(res, createNode(p->info));//
	}
	p = p->pNext;//tranh goi den nut cuoi co next la l.pHead
	for (; p!=l.pHead; p = p->pNext) {
		if (p->info >= x) {
			addLast(res, createNode(p->info));//
		}
	}
	return res;
}
void removeElementsIsMoreOrEqualX(LIST& l, ElementType x) {
	//duyet tung phan tu tu dau mang
	while (l.pHead != NULL && l.pHead->info >= x) {
		NODE* tmp = l.pHead;
		l.pHead = l.pHead->pNext;
		delete tmp;
	}
	//van con phan tu
	NODE* p = l.pHead;
	while (p->pNext!=l.pHead && p->pNext != NULL) {
		NODE* q = p->pNext;//q la nut sau p, q la nut can xoa
		if (q->info >= x) {
			p->pNext = q->pNext;
			delete q;
		}
		else {
			p = p->pNext;
		}
	}
}
void decresingQuickSort(LIST& l) {
	if (l.pHead == NULL) return;// da co thu tu (0-1 node)
	NODE* p, * x;//x luu gia tri key
	LIST l1, l2;
	initList(l1);
	initList(l2);
	x = l.pHead;
	for (p = l.pHead->pNext; p!=l.pHead;) {
		NODE* q = p;
		p = p->pNext;
		q->pNext = NULL;//co lap node dang xet
		if (q->info > x->info)
			addLast(l1, q);
		else
			addLast(l2, q);
	}
	decresingQuickSort(l1);
	decresingQuickSort(l2);
	//noi list1 + x +list2 = list
	if (l1.pHead != NULL) {
		l.pHead = l1.pHead;
		l1.pTail->pNext = x;
	}
	else
		l.pHead = x;
	x->pNext = l2.pHead;//
	if (l2.pHead != NULL) {
		l.pTail = l2.pTail;
	}
	else
		l.pTail = x;
	l.pTail->pNext = l.pHead;
}
LIST takeElementIsBiggest(LIST &l) {
	LIST res;
	initList(res);
	if (isEmptyList(l))	return res;
	decresingQuickSort(l);
	ElementType max = l.pHead->info;
	NODE* p = l.pHead;
	addLast(res, createNode(p->info));// gia su list chi co 1 phan tu -> no la lon nhat
	p = p->pNext;
	while (p != l.pHead && p->info == max) {//Khong phai nut cuoi list
		addLast(res, createNode(p->info));
		p = p->pNext;
	}
	return res;
}
int countNegativeElements(LIST l) {
	if (isEmptyList(l))	return 0;
	int count = 0;
	NODE* p = l.pHead;
	if (p->info < 0)
		count++;
	p = p->pNext;
	for ( ;p!=l.pHead; p = p->pNext)
		if (p->info < 0)
			count++;
	return count;
}


ElementType maxNegativeValue(LIST l) {
	ElementType max = -INT_MAX;
	bool flag = false;//gia su khong co gia tri am
	NODE* p = l.pHead;
	for (; p->pNext!=l.pHead; p = p->pNext) {
		if (p->info<0 && p->info>max) {
			max = p->info;
			flag = true;
		}
	}
	if (flag == false)
		return 0;//Khong co so am
	return max;
}
ElementType minPositiveValue(LIST l) {
	ElementType min = INT_MAX;
	bool flag = false;
	NODE* p = l.pHead;
	for (; p->pNext!=l.pHead; p = p->pNext) {
		if (p->info > 0 && min > p->info) {
			min = p->info;
			flag = true;
		}
	}
	if (flag == false)
		return -1;
	return min;
}
int countValueX(LIST l, ElementType x) {
	int count = 0;
	NODE* p = l.pHead;
	for (; p->pNext!=l.pHead; p = p->pNext)
		if (p->info == x)
			count++;
	return count;
}

void enterElement(int& x) {
	infile >> x;
}
void enterList(LIST& l) {
	int n;
	infile >> n;
	for (int i = 0; i < n; i++)
	{
		ElementType x;
		enterElement(x);
		addLast(l, x);
	}
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
