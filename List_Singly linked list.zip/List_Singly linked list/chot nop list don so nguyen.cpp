#include<iostream>
#include<string>
#include<fstream>
using namespace std;
#define elementType int
struct NODE {
	elementType info;
	struct NODE* next;
};
struct LIST {
	NODE* head;
	NODE* tail;
};
ifstream infile;
ofstream outfile;
void initList(LIST& l);
NODE* createNode(elementType x);
int isEmptyList(LIST l);
void addFirst(LIST& l, elementType x);
void addLast(LIST& l, elementType x);
void removeFirst(LIST& l);
void removeLast(LIST& l);
elementType searchNode(LIST l, NODE *x);
void printElement(int a);
void printList(LIST l);
void addLast(LIST& l, NODE* p);
void QuickSort(LIST& l);
void doSort(LIST& l);
LIST takeElementsIsMoreOrEqualX(LIST l, elementType x);
void removeElementsIsMoreOrEqualX(LIST& l, elementType x);
void decresingQuickSort(LIST& l);
LIST takeElementIsBiggest(LIST &l);
int countNegativeElements(LIST l);
elementType maxNegativeValue(LIST l);
elementType minPositiveValue(LIST l);
int countValueX(LIST l, elementType x);


void enterElement(int& x);
void enterList(LIST& l);
int main(int argc, char* argv[])
{
	infile.open("C:\\Users\\HP\\OneDrive\\Documents\\V� L� KH�NH DUY\\dsa\\input dslk don so nguyen.txt");
	outfile.open("C:\\Users\\HP\\OneDrive\\Documents\\V� L� KH�NH DUY\\dsa\\output dslk don so nguyen.txt");
	LIST l;
	initList(l);
	enterList(l);
	outfile << "Danh sach sau khi doc file: \n";
	printList(l);
	outfile << "\n---------------\n";
	outfile << "Danh sach lay ra phan tu >= 5: ";
	LIST l2 = takeElementsIsMoreOrEqualX(l, 5);
	outfile << "\n";
	printList(l2);
	outfile << "\n---------------\n";

	outfile << "Danh sach sau khi xoa phan tu >= 5: \n";
	removeElementsIsMoreOrEqualX(l, 5);
	printList(l);
	outfile << "\n---------------\n";

	LIST l3 = takeElementIsBiggest(l);
	outfile << "Danh sach lay ra cac phan tu lon nhat \n";
	printList(l3);
	outfile << "\n---------------\n";

	outfile <<"So luong cac phan tu am: " << countNegativeElements(l);
	outfile << "\n---------------\n";

	int res = maxNegativeValue(l);
	if (res == 0)
		outfile << "\nKhong co so am lon nhat mang!";
	else
		outfile << "\nSo am lon  nhat mang: " << res;
	outfile << "\n---------------\n";

	int res2 = minPositiveValue(l);
	if (res2 != -1)
		outfile << "\nGia tri duong nho nhat mang: " << res2;
	else
		outfile << "\nKhong co gia tri duong nho nhat mang!";
	outfile << "\n---------------\n";

	int tmp3=1;
	int res3 = countValueX(l,tmp3);
	if (res3 != 0)
		outfile << "\nSo phan tu co gia  tri bang "<<tmp3<<": " << res3;
	else
		outfile << "\nKhong co gia tri nao bang "<<tmp3;
	infile.close();
	outfile.close();
	return 0;
}
void initList(LIST& l) {
	l.head = l.tail = NULL;
}
NODE* createNode(elementType x) {
	NODE* p;
	p = new NODE;
	if (p == NULL) {
		outfile << "\nBo nho day! Khong tao node duoc!";
		exit(1);
	}
	p->info = x;
	p->next = NULL;
	return p;
}
int isEmptyList(LIST l) {
	if (l.head == NULL)	return 1;
	return 0;
	//1 dung, 0 sai
}
void addFirst(LIST& l, elementType x) {
	NODE* p = createNode(x);
	if (isEmptyList(l))
	{
		l.head = p;
		l.tail = p;
	}
	else {
		p->next = l.head;
		l.head = p;
	}
}
void addLast(LIST& l, elementType x) {
	NODE* p = createNode(x);
	if (isEmptyList(l))
		l.head = l.tail = p;
	else {
		l.tail->next = p;
		l.tail = p;
	}
}
void removeFirst(LIST& l) {
	if (isEmptyList(l))
		outfile << "Khong huy duoc do danh sach rong! ";
	else {
		if (l.head == l.tail)
			l.head = l.tail = NULL;
		else {
			NODE* p = l.head;
			l.head = l.head->next;
			delete p;
		}
	}
}
void removeLast(LIST& l) {
	if (isEmptyList(l)) {
		outfile << "\nList rong! Khong huy duoc!";
		exit(1);
	}
	else {
		if (l.head == l.tail)//1 phan tu
		{
			l.head = NULL;
			l.tail = NULL;
		}
		else {
			//nhieu hon 1 phan tu
			NODE* p = l.head;// p la nut truoc l.tail
			while (p->next != l.tail) {
				p = p->next;
			}
			delete l.tail;
			l.tail = p;
			l.tail->next = NULL;
		}
	}
}
elementType searchNode(LIST l, NODE* x) {
	if (x == NULL)
		exit(1);
	else {
		NODE* p = l.head;
		while (p != x) {
			p = p->next;
		}
		if (p != NULL)
			return p->info;
	}
}
void printList(LIST l) {
	for (NODE* p = l.head; p != NULL; p = p->next) {
		printElement(p->info);
		outfile << "\n";
	}
	outfile << "\n";
}
void printElement(int a) {
	outfile << a << " ";
}
void addLast(LIST& l, NODE* p) {
	if (isEmptyList(l))
		l.head = l.tail = p;
	else {
		l.tail->next = p;
		l.tail = p;
	}
}
void QuickSort(LIST& l) {
	if (l.head == l.tail) return;// da co thu tu (0-1 node)
	NODE* p, * x;//x luu gia tri key
	LIST l1, l2;
	initList(l1);
	initList(l2);
	x = l.head;
	for (p = l.head->next; p != NULL;) {
		NODE* q = p;
		p = p->next;
		q->next = NULL;//co lap node dang xet
		if (q->info <= x->info)
			addLast(l1, q);
		else
			addLast(l2, q);
	}
	QuickSort(l1);
	QuickSort(l2);
	//noi list1 + x +list2 = list
	if (l1.head != NULL) {
		l.head = l1.head;
		l1.tail->next = x;
	}
	else
		l.head = x;
	x->next = l2.head;//
	if (l2.head != NULL) {
		l.tail = l2.tail;
	}
	else
		l.tail = x;
}
void doSort(LIST& l) {
	QuickSort(l);
}
LIST takeElementsIsMoreOrEqualX(LIST l, elementType x) {
	LIST res;
	initList(res);
	NODE* p = l.head;
	for (; p != NULL; p = p->next) {
		if (p->info >= x) {
			addLast(res, createNode(p->info));//
		}
	}
	return res;
}
/*void removeElementsIsMoreOrEqualX(LIST& l, elementType x) {

	NODE *p=l.head;
	for (; p != NULL; ) {
		NODE *q = p->next;//q la nut sau p
		if (q->info >= x) {
			p->next = q->next;
			delete q;
		}
		else {
			p = p->next;
		}
	}
}*/
void removeElementsIsMoreOrEqualX(LIST& l, elementType x) {
	//duyet tung phan tu tu dau mang
	while (l.head != NULL && l.head->info >= x) {
		NODE* tmp = l.head;
		l.head = l.head->next;
		delete tmp;
	}
	//van con phan tu
	NODE* p = l.head;
	while(p != NULL&&p->next!=NULL) {
		NODE* q = p->next;//q la nut sau p, q la nut can xoa
		if (q->info >= x) {
			p->next = q->next;
			delete q;
		}
		else {
			p = p->next;
		}
	}
}
void decresingQuickSort(LIST& l) {
	if (l.head == l.tail) return;// da co thu tu (0-1 node)
	NODE* p, * x;//x luu gia tri key
	LIST l1, l2;
	initList(l1);
	initList(l2);
	x = l.head;
	for (p = l.head->next; p != NULL;) {
		NODE* q = p;
		p = p->next;
		q->next = NULL;//co lap node dang xet
		if (q->info > x->info)
			addLast(l1, q);
		else
			addLast(l2, q);
	}
	decresingQuickSort(l1);
	decresingQuickSort(l2);
	//noi list1 + x +list2 = list
	if (l1.head != NULL) {
		l.head = l1.head;
		l1.tail->next = x;
	}
	else
		l.head = x;
	x->next = l2.head;//
	if (l2.head != NULL) {
		l.tail = l2.tail;
	}
	else
		l.tail = x;
}
/*LIST takeElementIsBiggest(LIST& l) {
	LIST res;
	initList(res);
	decresingQuickSort(l);
	elementType max = l.head->info;
	NODE* p = l.head;
	while (p->info == max) {
		addLast(res, p);
		p = p->next;
	}
	return res;
	// loi: res va l cung tro
}
*/
LIST takeElementIsBiggest(LIST& l) {
	LIST res;
	initList(res);
	decresingQuickSort(l);
	elementType max = l.head->info;
	NODE* p = l.head;
	while (l.head != NULL && l.head->info == max) {
		NODE* tmp = l.head;
		l.head = l.head->next; // di chuyen head ve sau
		tmp->next = NULL;      // co lap nut max
		addLast(res, tmp);     // them nut lon nhat vao list res
	}
	return res;
}
int countNegativeElements(LIST l) {
	int count = 0;
	for (NODE* p = l.head; p != NULL; p = p->next)
		if (p->info < 0)
			count++;
	return count;
}
elementType maxNegativeValue(LIST l) {
	elementType max = -INT_MAX;
	bool flag = false;//gia su khong co gia tri am
	NODE* p = l.head;
	for (; p != NULL; p = p->next) {
		if (p->info<0 && p->info>max) {
			max = p->info;
			flag = true;
		}
	}
	if (flag == false)
		return 0;//Khong co so am
	return max;
}
elementType minPositiveValue(LIST l) {
	elementType min = INT_MAX;
	bool flag = false;
	NODE* p = l.head;
	for (; p != NULL;p=p->next) {
		if (p->info > 0 && min > p->info) {
			min = p->info;
			flag = true;
		}
	}
	if (flag == false)
		return -1;
	return min;
}
int countValueX(LIST l, elementType x) {
	int count = 0;
	NODE* p = l.head;
	for (; p != NULL; p = p->next)
		if (p->info == x)
			count++;
	return count;
}

void enterElement(int& x) {
	infile >> x;
}
void enterList(LIST& l) {
	int n;
	infile >> n;
	for (int i = 0; i < n; i++)
	{
		elementType x;
		enterElement(x);
		addLast(l, x);
	}
}