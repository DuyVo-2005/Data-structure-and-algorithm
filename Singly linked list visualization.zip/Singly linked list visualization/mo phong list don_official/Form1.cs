﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mo_phong_list_don_official
{
    public partial class Form1 : Form
    {
        public class Node
        {
            public int Value;
            public Node Next;

            public Node(int value)
            {
                Value = value;
                Next = null;
            }
        }

        public class LinkedList
        {
            public Node Head;
            public Node Tail;
            public LinkedList()
            {
                Head = null;
                Tail = null;
            }

            public void AddFirst(int value)
            {
                Node newNode = new Node(value);
                newNode.Next = Head;
                Head = newNode;
            }

            public void AddLast(int value)
            {
                Node newNode = new Node(value);
                if (Head == null)
                {
                    Head = newNode;
                }
                else
                {
                    Node current = Head;
                    while (current.Next != null)
                    {
                        current = current.Next;
                    }
                    current.Next = newNode;
                }
            }

            public void RemoveFirst()
            {
                if (Head != null)
                {
                    Head = Head.Next;
                }
            }

            public void RemoveLast()
            {
                if (Head == null) return;

                if (Head.Next == null)
                {
                    Head = null;
                    return;
                }

                Node current = Head;
                while (current.Next.Next != null)
                {
                    current = current.Next;
                }
                current.Next = null;
            }

            public bool Search(int value)
            {
                Node current = Head;
                while (current != null)
                {
                    if (current.Value == value)
                        return true;
                    current = current.Next;
                }
                return false;
            }

            public string Display()
            {
                Node current = Head;
                string result = "";
                while (current != null)
                {
                    result += current.Value + " -> ";
                    current = current.Next;
                }
                return result + "null";
            }
        }
        private LinkedList myList = new LinkedList();
        public Form1()
        {
            InitializeComponent();
        }
        private void UpdateListBox()
        {
            listBox1.Items.Clear();
            listBox1.Items.Add(myList.Display());
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void AddFirst_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int newValue))
            {//kiểm tra xem chuỗi văn bản (textBox1.Text) có được chuyển đổi thành một số nguyên hay không
                myList.AddFirst(newValue);
                UpdateListBox();
                textBox1.Clear();
            }
            else
            {
                MessageBox.Show("Vui lòng nhập một số nguyên hợp lệ!");
            }
        }

        private void AddLast_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int newValue))
            {
                myList.AddLast(newValue);
                UpdateListBox();
                textBox1.Clear();
            }
            else
            {
                MessageBox.Show("Vui lòng nhập một số nguyên hợp lệ!");
            }
        }
        private void RemoveLast_Click(object sender, EventArgs e)
        {
            myList.RemoveLast();
            UpdateListBox();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            myList.RemoveFirst();
            UpdateListBox();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int searchValue))
            {
                bool found = myList.Search(searchValue);
                MessageBox.Show(found ? "Phần tử tồn tại trong danh sách!" : "Phần tử không tồn tại trong danh sách!");
            }
            else
            {
                MessageBox.Show("Vui lòng nhập một số nguyên hợp lệ!");
            }
        }
    }
}